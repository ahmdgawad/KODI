# -*- coding: utf-8 -*-
from LIBRARY import *
import smtplib
#import requests

def MAIN(mode,text):

	if (mode==0 or mode==1):
		keyboard=text
		if keyboard=='': return
		if mode==1:
			window_id = xbmcgui.getCurrentWindowDialogId()
			window = xbmcgui.Window(window_id)
			keyboard = mixARABIC(keyboard)
			window.getControl(311).setLabel(keyboard)
		elif mode==0:
			ttype='X'
			check=isinstance(keyboard, unicode)
			if check==True: ttype='U'
			new1=str(type(keyboard))+' '+keyboard+' '+ttype+' '
			for i in range(0,len(keyboard),1):
				new1 += hex(ord(keyboard[i])).replace('0x','')+' '
			keyboard = mixARABIC(keyboard)
			ttype='X'
			check=isinstance(keyboard, unicode)
			if check==True: ttype='U'
			new2=str(type(keyboard))+' '+keyboard+' '+ttype+' '
			for i in range(0,len(keyboard),1):
				new2 += hex(ord(keyboard[i])).replace('0x','')+' '
			xbmcgui.Dialog().ok(new1,new2)

	elif mode==2:
		message1 = '1.   If you can\'t see Arabic Letters then go to "Kodi Interface Settings" and change the font to "Arial"'
		message2 = '2.   If you can\'t see "Arial" in kodi skin fonts then go to "Kodi Interface Settings" and change your skin to another skin that accepts "Arial" font'
		xbmcgui.Dialog().ok('Arabic Problem',message1)
		xbmcgui.Dialog().ok('Font Problem',message2)

	elif mode==3:
		message1 = 'هذا الموقع بحاجة الى ربط مشفر حاول تنزيل شهادة التشفير على كودي او استخدم اصدار اخر لكودي  مثل اصدار 17.6'
		xbmcgui.Dialog().ok('المواقع المشفرة',message1)

	elif mode==4:
		search =''
		keyboard = xbmc.Keyboard(search, 'Search')
		keyboard.doModal()
		if keyboard.isConfirmed(): search = keyboard.getText()
		if len(search)<2: return
		message = mixARABIC(search)
		yes = xbmcgui.Dialog().yesno('هل ارسل هذه الرسالة',message)
		if yes: 
			emailAddress = 'emad.mahdi1@gmail.com'
			header  = 'From: ' + emailAddress
			header += '\nTo: ' + emailAddress
			#header += '\nCc: ' + emailAddress
			header += '\nSubject: من كودي الفيديو العربي'
			server = smtplib.SMTP('smtp.mailgun.org',25)
			#server.starttls()
			server.login('postmaster@sandboxfe7bf101a6084f8b9154ec2a64458802.mailgun.org','8811df99282f4d018a63e26a4176a8a0-7bbbcb78-ca8905a9')
			problems = server.sendmail(emailAddress,emailAddress, header + '\n' + message)
			server.quit()
		#requests.post(
		#	"https://api.mailgun.net/v3/my allowed sending domain/messages",
		#	auth=("api", "my personal api key"),
		#	data={"from": "emad.mahdi1@gmail.com",
		#	"to": ["emad.mahdi1@gmail.com"],
		#	"subject": "From kodi API",
		#	"text": "Testing some Mailgun awesomeness!"})




